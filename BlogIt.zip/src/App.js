import { useState, useEffect } from "react";
import "./App.css";
import Axios from "axios";
import FrontPage from "./components/FrontPage/FrontPage";

import { Route, Link, BrowserRouter as Router, Routes } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import UserState from "./context/UserState";
// import UserContext from "./context/UserContext";
import Navbar from "./components/Navbar/Navbar";
import EditPage from "./components/CreateBlog/CreatePage";
import Login from "./components/LoginPage/Login";
import "react-toastify/dist/ReactToastify.css";
import CreatePage from "./components/CreateBlog/CreatePage";
import Profile from "./components/Profile/Profile";
function App() {
  // const [name, setName] = useState("");
  // const [number, setNumber] = useState(0);
  // const [newName, setnewName] = useState("");

  // useEffect(() => {
  //   Axios.get("http://localhost:8000/read").then((response) => {
  //     setData_from_backend_list(response.data);
  //   });
  // }, []);

  // const [data_from_backend_list, setData_from_backend_list] = useState([]);

  // const addToList = () => {
  //   // console.log(inputValues.name + " "  + inputValues.number);
  //   Axios.post("http://localhost:8000/insert", { name: name, number: number });
  // };

  // const updateData = (id) => {
  //   Axios.put("http://localhost:8000/update", { id: id, newName: newName });
  // };

  // const deleteName = (id) => {
  //   Axios.delete(`http://localhost:8000/delete/${id}`);
  // };

  const [username , setUsername] = useState("")
  return (
    // <div className="App">
    //   <h1>Crud App with mern </h1>

    //   <div className="inputs">
    //     <input
    //       type="text"
    //       name="name"
    //       value={name}
    //       onChange={(e) => {
    //         setName(e.target.value);
    //       }}
    //       placeholder="Enter Your Name"
    //     />
    //     <input
    //       type="number"
    //       name="number"
    //       value={number}
    //       onChange={(e) => {
    //         // setInputValues({ ...inputValues , [e.target.name] : e.target.value })
    //         setNumber(e.target.value);
    //       }}
    //       placeholder="Enter Your Number"
    //     />

    //     <button onClick={addToList}>Add To List</button>
    //     <hr />
    //     <div className="datafromthebackend">
    //       <h1>Data</h1>
    //       {data_from_backend_list.map((val, key) => {
    //         return (
    //           <div
    //             key={key}
    //             style={{
    //               border: "2px solid red",
    //               padding: "10px 10px",
    //               width: "400px",
    //               margin: "20px 30px",
    //             }}
    //           >
    //             <h1>{val.name}</h1>
    //             <p>{val.number}</p>
    //             <input
    //               type="text"
    //               name="newName"
    //               // value={newName}
    //               onChange={(e) => {
    //                 // setInputValues({...inputValues , [e.target.name] : e.target.value })
    //                 setnewName(e.target.value);
    //               }}
    //               placeholder="Enter New Name...."
    //             />
    //             <button onClick={() => updateData(val._id)}>Update</button>
    //             <button style={{ cursor: "pointer" }} onClick={() => deleteName(val._id)}>Delete</button>
    //           </div>
    //         );
    //       })}
    //     </div>
    //   </div>
    // </div>
    <>
    <ToastContainer
        position="top-center"
        autoClose={2000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />

    <Router>
      <div className="App">
        <UserState>
          <Navbar />
          <Routes>
            <Route path="/" element={<FrontPage />} />
            <Route path="/edit" element={<EditPage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/front" element={<FrontPage />} />
            <Route path="/create" element={<CreatePage />} />
            <Route path="/profile" element={<Profile />} />



          </Routes>
          {/* <Footer /> */}
        </UserState>
      </div>
    </Router>
    </>
  );
}

export default App;

