import { useContext , useState} from 'react'
import React from 'react'
// import UserContext from '../../context/UserContext'
import UserContext from '../../context/UserContext'
import Navbar from '../Navbar/Navbar'

import "../FrontPage/FrontPage.css"
import Blog from '../Blogs/Blog'
import { useNavigate } from 'react-router'



const FrontPage = () => {
    const data = useContext(UserContext)

    // const {setUsername} = useContext(UserContext);
    const navigate = useNavigate()
    const create = (e) => {
        navigate("/create")

    }



  return (
    <div>
        {/* <Navbar/> */}
        <div className="front_page">
            <div className="middle_box">
                <h3>Welcome To The Blog World !!!!!!!</h3>
            </div>
            <div className="categories">
                <ul>
                    <li>Social Networks</li>
                    <li>Games</li>
                    <li>Politics</li>
                    <li>Web </li>
                    <li>Technology</li>
                    <li>Marketing</li>
                </ul>
            </div>

            <div className="top_blogs">
                <Blog/>
                <Blog/>
                <Blog/>
            </div>

            <div className="create_blog_page">
                <button onClick={create} >Create Your Own Blog</button>
            </div>
        </div>

        
    </div>
    
  )
}

export default FrontPage