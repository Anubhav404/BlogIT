import React from 'react'
// import "./Blog.css"
import blog1image from "../utilities/images/blog1image.jpg"
const Blog = () => {
  return (
    <>
        <div className="box" style={{
            // border:"2px solid red",
            width:"90vh",
            padding:"10px 10px",
            height:"45vh",
            // display:'flex'

        }} >
            <div className="imagebox" style={{
                backgroundImage: `url(${blog1image})`,
                height:"160px",
                textAlign:"center",
                padding:"20px 0px",
                // width:

            }}>
                <h3 style={{
                    // marginTop:"50px"
                fontWeight:"700",
                }}>Title</h3>
            </div>
            <div className="text" style={{
                // border:"2px solid red",
                background:"grey",
                // height:"50px",
                fontWeight:"600",
                padding:"10px"

            }}>
                <p style={{
                    // marginTop:'10px'
                }}>How to Win a Hack-a-thon ?</p>
            </div>
        </div>
    </>
  )
}

export default Blog