import React, { useState , useContext} from 'react'
import "./CreatePage.css"
import UserContext from '../../context/UserContext'

import { toast } from "react-toastify";
import { useNavigate } from 'react-router';
const CreatePage = () => {

  const data = useContext(UserContext);
  const navigate = useNavigate()
  const [img, setImg] = useState();

  const [blogData , setBlogData] = useState({
    title:"",
    description:"",
    about:"",
    file:img
  })

  


  const onImageChange = (e) => {
    const [file] = e.target.files;
    setImg(URL.createObjectURL(file));
    setBlogData({...blogData , [e.target.name] : e.target.value })
  };
  
  return (
    <div>
        <div className="create_heading">
          <h3 style={{textAlign :"center" , color :"white" , marginTop:"20px"}}>Create Your Own Blog!</h3>
        </div>

        <div className="create_box">
          <div className="blog_heading">
              <label htmlFor="bloghead">Title</label>
              <input type="text"  id='bloghead' value={blogData.title} name="title" placeholder='Enter Blog Title....'  onChange={(e)=>{
                  setBlogData({...blogData , [e.target.name] : e.target.value})

                  // localStorage.setItem("title" , e.target.value);

              }} />
          </div>
          <div className="blog_title_description">
              <label htmlFor="blogdesc">Description</label>
              <textarea  id="blogdesc" value={blogData.description} name="description" cols="30" rows="2" onChange={(e)=>{
                  setBlogData({...blogData , [e.target.name] : e.target.value})

                  // localStorage.setItem("description" , e.target.value);


              }} ></textarea>
          </div>
          <div className="blog_image">
              {/* <label htmlFor="blogimg">Image</label> */}
              {/* <span style={{color:"black"}} >Image</span> */}
              <input type="file" onChange={onImageChange} value={blogData.file}  id='blogimg' alt=""   />
              <img src={img} alt="" />

              

          </div>
          <div className="about_blog">
              <label htmlFor="aboutblog">About</label>
              <textarea  id='aboutblog' cols="30" value={blogData.about} name="about" rows="10"  onChange={(e)=>{
                  setBlogData({...blogData , [e.target.name] : e.target.value})

                  // localStorage.setItem("about" , e.target.value);


              }} ></textarea>
          </div>

          <div className="create_button">
            <button onClick={() => {
              if(blogData.about === "" || blogData.description === ""  || blogData.file === "" || blogData.title === ""){
                toast.error("Error all data ");
              }
              else{
                data.setUser({...data.user , ["title"] : blogData.title , ["description"] : blogData.description , ["about"] : blogData.about  , ["file"] : img,
                })
                navigate("/profile")

                // localStorage.setItem("image" , img);

                // localStorage.setItem("blogValues" , JSON.stringify(blogData))

                // data.setBlogsList([...data.blogslist , blogData])
                localStorage.setItem("blogArray", JSON.stringify([...data.blogslist , data.user]))
                // console.log(data.blogslist)
              }
            }}>Create</button>
          </div>
        </div>
    </div>
  )
}

export default CreatePage