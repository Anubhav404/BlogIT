import React, { useContext } from "react";
import UserContext from "../../context/UserContext";
import "./Profile.css";
const Profile = () => {
  const data = useContext(UserContext);
    // const data = JSON.parse(localStorage.getItem("blogArray"))
    console.log(data);
  var m = JSON.parse(localStorage.getItem("blogValues"));

  return (
    <>
      <div className="profile">
        {data.blogslist.map((val , key) => {
          return (
            
              <div className="blog_box" id="bbox" key={key}>
                <div className="title">
                  {/* <h3>{data.user.title}</h3> */}
                  <h3>{m.title}</h3>
                </div>
                <div className="description">
                  {/* <p>{data.user.description}</p> */}
                  {/* <p>{localStorage.getItem("description")}</p> */}
                  <p>{m.description}</p>
                </div>
                <div className="image">
                  <img src={data.user.file} alt="" />
                  {/* <img  src={localStorage.getItem("image")} alt="" /> */}
                  {/* <img src={m.file} alt="" /> */}
                </div>
                <div className="about">
                  {/* <p>{data.user.about}</p> */}
                  {/* <p>{localStorage.getItem("about")}</p> */}
                  <p>{m.about}</p>
                </div>
                <div className="readmore">
                  <button
                    onClick={(e) => {
                      // alert("clicked")
                      // document.getElementById("bbox").style.overflow ="visible";
                      // document.getElementById("bbox").style.height ="80vh";
                      var element = document.getElementById("bbox");
                      element.classList.toggle("toggleClass");
                    }}
                  >
                    Read More
                  </button>
                </div>
              </div>
            
          );
        })}
      </div>
    </>
  );
};

export default Profile;
