import React , {useContext, useState} from "react";
import "./Login.css";
import UserContext from "../../context/UserContext";
import { useNavigate } from "react-router";
import { toast } from "react-toastify";
const Login = () => {

  const data = useContext(UserContext)
  const navigate = useNavigate()

  const switchers = [...document.querySelectorAll(".switcher")];

  switchers.forEach((item) => {
    item.addEventListener("click", function () {
      switchers.forEach((item) =>
        item.parentElement.classList.remove("is-active")
      );
      this.parentElement.classList.add("is-active");
    });
  });

  const [signupValues , setSignupvalues] = useState({
        name :"",
        email : "",
        password :""
  })

  const [loginValues , setLoginValues] = useState({
    name :"",
    email : " ",
    password :" "
})

   
const signup = (e) => {
    e.preventDefault();
    localStorage.setItem("SignUpValues" , JSON.stringify(signupValues));

    const values = localStorage.getItem("SignUpValues");
    console.log("Signup data " ,  JSON.parse(values));

    toast.success("Signed-In Success");



}

// const [email, setEmail] = useState("");
// const [password, setPassword] = useState("");   
// // const navigate = useNavigate();
// //getting email password
// const userName = localStorage.getItem(loginValues.email)
//   ? localStorage.getItem("email")
//   : "admin@admin.com";
// const userPassword = localStorage.getItem(loginValues.password)
//   ? localStorage.getItem("password")
//   : "admin";


const login = (e) => {
    e.preventDefault();
    localStorage.setItem("loginData" , JSON.stringify(loginValues));

    const loginvalues = localStorage.getItem('loginData');  

    // console.log("login data " ,  JSON.parse(loginvalues));
    // console.log(loginValues);
    data.setUser({...data.user , ["name"] : loginValues.name})
    data.setIsNavigate("true");
    
    const nameFromBackend = localStorage.getItem("SignUpValues")
    // console.log(nameFromBackend);

    var m = JSON.parse(localStorage.getItem("SignUpValues"));
    // console.log(m.name);/
    const logval = JSON.parse(localStorage.getItem("loginData"));
    if(m.name === logval.name ){
        navigate("/front")
    }
    else{
        alert("NO data present in backend")
    }


    
    
}
   return (
    <>
      <div className="loginbox">
        <section className="forms-section">
          <h1 className="section-title">User Login</h1>
          <div className="forms">
            <div className="form-wrapper is-active">
              <button type="button" className="switcher switcher-login">
                Login
                <span className="underline" />
              </button>
              <form className="form form-login">
                <fieldset>
                  <legend>
                    Please, enter your email and password for login.
                  </legend>
                  <div className="input-block">
                    <label htmlFor="login-email">Name</label>
                    <input id="login-name" type="text" name="name" onChange={(e) => {
                        setLoginValues({...loginValues , [e.target.name] : e.target.value })
                    }} required />
                  </div>
                  <div className="input-block"> 
                    <label htmlFor="login-email">E-mail</label>
                    <input id="login-email"  type="email" name="email" onChange={(e) => {
                        setLoginValues({...loginValues , [e.target.name] : e.target.value })
                    }} required />
                  </div>
                  <div className="input-block">
                    <label htmlFor="login-password">Password</label>
                    <input id="login-password" type="password" name="password" onChange={(e) => {
                        setLoginValues({...loginValues , [e.target.name] : e.target.value })
                    }} required />
                  </div>
                </fieldset>
                <button type="submit" onClick={login} className="btn-login">
                  Login
                </button>
              </form>
            </div>


            <div className="form-wrapper">
              <button type="button" className="switcher switcher-signup">
                Sign Up
                <span className="underline" />
              </button>
              <form className="form form-signup">


                <fieldset>
                  <legend>
                    Please, enter your email, password and password confirmation
                    for sign up.
                  </legend>

                  <div className="input-block">
                    <label htmlFor="signup-email">Name</label>
                    <input id="signup-name" type="text" name="name"   value={signupValues.name} onChange={(e) => {
                        setSignupvalues({...signupValues , [e.target.name] : e.target.value })
                    }} required />
                  </div>

                  <div className="input-block">
                    <label htmlFor="signup-email">E-mail</label>
                    <input id="signup-email" type="email" name="email"  value={signupValues.email}  onChange={(e) => {
                        setSignupvalues({...signupValues , [e.target.name] : e.target.value })
                    }} required />
                  </div>
                  <div className="input-block">
                    <label htmlFor="signup-password">Password</label>
                    <input id="signup-password" name="password" type="password" value={signupValues.password} onChange={(e) => {
                        setSignupvalues({...signupValues , [e.target.name] : e.target.value })
                    }} required />
                  </div>
                  
                </fieldset>
                <button type="submit" className="btn-signup" onClick={signup}>
                  Continue
                </button>
            
              </form>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Login;
