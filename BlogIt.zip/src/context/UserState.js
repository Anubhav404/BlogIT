import React, { useState, useEffect, useContext, Children } from "react";
import UserContext from "./UserContext";

// const UserContext = createContext();

const UserState = (props) => {

    const [user , setUser] = useState({
        name : "",
        title :"",
        description:"",
        imageurl:"",
        aboutblog:""
    
        })
    
    const [profileUrl , setProfileUrl] = useState("");

    const [isNavigate , setIsNavigate] =  useState("");

    const [blogslist  , setBlogsList] = useState([]);


    


    return (
        <UserContext.Provider value={{user, setUser , setProfileUrl , profileUrl , isNavigate , setIsNavigate , blogslist , setBlogsList}}>
           {props.children}
        </UserContext.Provider>
    )



}

export default UserState;